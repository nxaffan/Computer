function showMessage() {
    document.getElementById("message").innerHTML =
        "Thank you for visiting my portfolio!";
}